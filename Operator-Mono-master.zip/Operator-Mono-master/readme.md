
##  Operator-Mono

## 说明
一款非常优秀的代码字体,在这里做个备份


### 字体截图

<p align="center"><img src="http://i1.piimg.com/1949/02fd1e93eb33b638.png"></p>
<p align="center"><img src="http://i1.piimg.com/1949/42fd9f0feb547d6b.png"></p>
<p align="center"><img src="http://i1.piimg.com/1949/7cef3db7aaf858d7.png"></p>

## 使用

#### 1. Clone 资源文件


    $ git clone https://github.com/ScumPetard/Operator-Mono.git




